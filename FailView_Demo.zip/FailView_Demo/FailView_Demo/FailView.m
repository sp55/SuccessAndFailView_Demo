//
//  SuccessView.m
//  SuccessView_Demo
//
//  Created by admin on 2017/8/1.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import "FailView.h"

@interface FailView ()
@property(strong,nonatomic)UIView *logoView;
@end

@implementation FailView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        
        [self drawFailedLine];
        
    }
    return self;
}



- (void)drawFailedLine{
    
    [_logoView removeFromSuperview];
    _logoView = [[UIView alloc] initWithFrame:self.frame];
    //曲线建立开始点和结束点
    //1. 曲线的中心
    //2. 曲线半径
    //3. 开始角度
    //4. 结束角度
    //5. 顺/逆时针方向
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.center.x, self.center.y) radius:self.frame.size.width/2.0 startAngle:0 endAngle:M_PI*2 clockwise:YES];
    //对拐角和中点处理
    path.lineCapStyle  = kCGLineCapRound;
    path.lineJoinStyle = kCGLineCapRound;
    
    //差号第一部分折线
    [path moveToPoint:CGPointMake(self.frame.size.width*3/14, self.frame.size.width*3/14)];//起始点
    CGPoint p1 = CGPointMake(self.frame.size.width*11/14, self.frame.size.width*11/14);
    [path addLineToPoint:p1];
    
    
    //差号第二部分折线
    [path moveToPoint:CGPointMake(self.frame.size.width*11/14, self.frame.size.width*3/14 )];//起始点
    CGPoint p2 = CGPointMake(self.frame.size.width*3/14, self.frame.size.width*11/14);
    [path addLineToPoint:p2];
    
    CAShapeLayer *layer = [[CAShapeLayer alloc] init];
    //内部填充颜色
    layer.fillColor = [UIColor clearColor].CGColor;
    //线条颜色
    layer.strokeColor = [UIColor orangeColor].CGColor;
    //线条宽度
    layer.lineWidth = 3;
    layer.path = path.CGPath;
    //动画设置
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:NSStringFromSelector(@selector(strokeEnd))];
    animation.fromValue = @0;
    animation.toValue = @1;
    animation.duration = 2;
    [layer addAnimation:animation forKey:NSStringFromSelector(@selector(strokeEnd))];
    
    [_logoView.layer addSublayer:layer];
    [self addSubview:_logoView];
}
@end
