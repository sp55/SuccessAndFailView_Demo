//
//  ViewController.m
//  FailView_Demo
//
//  Created by admin on 2017/8/1.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import "ViewController.h"
#import "FailView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    FailView *suc = [[FailView alloc]initWithFrame:CGRectMake(0, 0, 60, 60)];
    suc.center = self.view.center;
    [self.view addSubview:suc];
}

@end
