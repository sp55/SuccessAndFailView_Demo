//
//  ViewController.m
//  SuccessView_Demo
//
//  Created by admin on 2017/8/1.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import "ViewController.h"
#import "SuccessView.h"


@interface ViewController ()
@property(strong,nonatomic)SuccessView *sucView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   

}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    self.sucView = [[SuccessView alloc]initWithFrame:CGRectMake(0, 0, 60, 60)];
    self.sucView.center = self.view.center;
    [self.view addSubview:self.sucView];
}

@end
