//
//  SuccessView.h
//  SuccessView_Demo
//
//  Created by admin on 2017/8/1.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuccessView : UIView



@end
